# Third-Party Notices

Ruri is an independent interoperability implementation. It does not
contain or redistribute RebornBuddy, GreyMagic, Lisbeth binaries, `db.bin`,
private service responses, or authentication material.

## Artisan

Craft-state formulas, solver interface patterns, and job-specific action resolution patterns
were adapted from Artisan:

- Project: https://github.com/PunishXIV/Artisan
- Reviewed commit: `ac244f17064b2e117c79d41143d2b519de22d7e0`
- Relevant files: `Artisan/CraftingLogic/Simulator.cs`,
  `Artisan/CraftingLogic/State.cs`,
  `Artisan/CraftingLogic/Solvers/StandardSolver.cs`, and
  `Artisan/RawInformation/Character/Skills.cs`
- License: BSD-3-Clause

BSD 3-Clause License

Copyright (c) 2023, Puni.sh

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

## LlamaLibrary order model

The public JSON field names documented by LlamaLibrary were used as an
interoperability reference:

- Project: https://github.com/nt153133/__LlamaLibrary
- Reviewed commit: `5f216df303e0f91913cc062f278fd8ac724a3042`
- Relevant file: `JsonObjects/Lisbeth/Order.cs`
- License: MIT

MIT License

Copyright (c) 2022 nt153133

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Lumin UI framework

The order editor's visual system (theme colors/metrics, draw helpers and the
search field / primary button / switch / section-card widgets) was adapted from
the Lumin ImGui framework:

- Project: https://github.com/Pondot/Lumin-Free-Imgui-Menu
- Reviewed commit: `689a9751b295585854496f7553fbb73240f1c8fe` (2026-05-29)
- Relevant files: `framework/settings/colors.h`, `framework/settings/elements.h`,
  `framework/helpers/draw.cpp`, `framework/widgets/widgets.cpp`,
  `framework/widgets/text_field.cpp`
- Adaptation: minimal theme/draw/widget subset embedded under
  `Ruri.Ui.Lumin`; the API-15 binding patterns follow the BOCCHI
  plugin's verified port of the same framework. No BOCCHI or PromeRotation
  business logic is included.
- License: MIT

MIT License

Copyright (c) 2026 Pondot

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Additional references

AtmoOmen/GatherBuddyReborn (`5038325beb301bcceb9b1ffbe40b9c973b23ddca`,
Apache-2.0) and GarlandTools-CN
(`95e7ce7e5b0ced16423524679cd67167bfffaaf6`, MIT) were reviewed for public
data semantics and interoperability patterns. Ruri interoperates with the
separately installed CN GatherBuddyReborn through its IPC v2 and version-guarded
CraftingGatherBridge reflection surface; no GatherBuddyReborn or GarlandTools-CN
source/runtime files are included in the Ruri plugin archive.
