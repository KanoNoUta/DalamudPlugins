# Third-Party Notices

Ruri is an independent interoperability implementation. It does not
contain or redistribute RebornBuddy, GreyMagic, Lisbeth binaries, `db.bin`,
private service responses, or authentication material.

## Artisan

Craft-state formulas, solver interface patterns, and job-specific action resolution patterns
were adapted from Artisan:

- Project: https://github.com/PunishXIV/Artisan
- Reviewed commit: `ac244f17064b2e117c79d41143d2b519de22d7e0`
- Relevant files: `Artisan/CraftingLogic/Simulator.cs`,
  `Artisan/CraftingLogic/State.cs`,
  `Artisan/CraftingLogic/Solvers/StandardSolver.cs`, and
  `Artisan/RawInformation/Character/Skills.cs`
- License: BSD-3-Clause

BSD 3-Clause License

Copyright (c) 2023, Puni.sh

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

## LlamaLibrary order model

The public JSON field names documented by LlamaLibrary were used as an
interoperability reference:

- Project: https://github.com/nt153133/__LlamaLibrary
- Reviewed commit: `5f216df303e0f91913cc062f278fd8ac724a3042`
- Relevant file: `JsonObjects/Lisbeth/Order.cs`
- License: MIT

MIT License

Copyright (c) 2022 nt153133

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Lumin UI framework

The order editor's visual system (theme colors/metrics, draw helpers and the
search field / primary button / switch / section-card widgets) was adapted from
the Lumin ImGui framework:

- Project: https://github.com/Pondot/Lumin-Free-Imgui-Menu
- Reviewed commit: `689a9751b295585854496f7553fbb73240f1c8fe` (2026-05-29)
- Relevant files: `framework/settings/colors.h`, `framework/settings/elements.h`,
  `framework/helpers/draw.cpp`, `framework/widgets/widgets.cpp`,
  `framework/widgets/text_field.cpp`
- Adaptation: minimal theme/draw/widget subset embedded under
  `Ruri.Ui.Lumin`; the API-15 binding patterns follow the BOCCHI
  plugin's verified port of the same framework. No BOCCHI or PromeRotation
  business logic is included.
- License: MIT

MIT License

Copyright (c) 2026 Pondot

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## AutoHook (spearfishing window facts)

Ruri's spearfishing code (`src/Ruri.Fishing/Spearfishing.cs`, `SpearfishingGame.cs`,
`SpearSession.cs`) is Ruri's own; AutoHook was read as a reference and the following facts were
taken from it. No source code was copied.

- Project: https://github.com/PunishXIV/AutoHook
- Commit: `70b0808a409e902d9658e51d06618e19093d5de9` (reviewed 2026-11-23)
- Files: `AutoHook/Spearfishing/AutoGig.cs`, `AutoHook/Modules/Gig/GigComponent.cs`,
  `AutoHook/World/UpdateModules/SpearfishingUpdateModule.cs`,
  `AutoHook/Presets/AutoCasts/Auto{VitalSight,BaitedBreath,ElectricCurrent,NaturesBounty,ThaliaksFavor}.cs`,
  `AutoHook/Data/IDs.cs`
- Facts used: addon node ids 43 (fish lanes) and 61/60/59 (fish), the fish head at 0.4 / 0.5 of
  its node and the spear line in the middle of the lanes container, the default 25 px hit zone,
  the wariness gauge (`GaugeBar.Values[0]`/`MaxValue`), and which skills AutoHook casts in the
  window with their stack/GP thresholds. Cross-checked with GatherBuddyReborn
  (https://github.com/FFXIV-CombatReborn/GatherBuddyReborn, `9e2bdcd9904814d15fae61742b8a53908254ada9`,
  Apache-2.0: `GatherBuddy/SeFunctions/AddonSpearFishingExtensions.cs`,
  `GatherBuddy/Spearfishing/SpearfishingHelper.Ui.cs`, `GatherBuddy/AutoGather/AutoGather.Spearfishing.cs`).
- Changes: own tracking of each fish's measured speed, learned throw distance, result
  bookkeeping from the client's log messages, own skill order.
- License: BSD-3-Clause

Copyright (c) 2024, Puni.sh. The BSD 3-Clause conditions and disclaimer are the same as printed
for Artisan above.

## GatherBuddyReborn (data for the built-in gathering engine)

Ruri's gathering engine (`Ruri.Gathering.dll`) is Ruri's own code; GatherBuddyReborn was
used as a behaviour reference. The engine bundles the following GatherBuddyReborn data:

- Project: https://github.com/AtmoOmen/GatherBuddyReborn (CN fork of
  https://github.com/FFXIV-CombatReborn/GatherBuddyReborn, itself a fork of
  Ottermandias' GatherBuddy)
- Commit: `e3c1e4c2` (plugin version 7.5.0.5)
- Files: gathering point positions (`world_locations.json`) and node standing offsets
  (`node_offsets.json`), unchanged; the fish database from
  `GatherBuddy.GameData/Data/Fish/Data*.cs`, converted to `fish_data.json` (format change
  only) by `tools/fish-data/export_gbr_fish_db.py`; the Diadem windmire positions, converted
  to `diadem_windmires.json` (format change only); fishing stand positions (player position
  and facing per fishing spot) taken from the crowd-sourced catch records in
  `GatherBuddy/CustomInfo/fish_records.json`, converted to `fishing_spot_positions.json` by
  `tools/fish-data/export_gbr_spot_positions.py` (only spot id, position and rotation kept;
  points within 2 yalms merged, at most 40 per spot).
- License: Apache-2.0 (full text below)

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

## Garland Tools CN (bundled NPC shop and crafter/gatherer gear snapshot)

`src/Ruri.Adapters.Dalamud/Data/garland-vendors.json` and
`src/Ruri.Adapters.Dalamud/Data/garland-crafter-gear.json` are an offline snapshot of
public documents from https://garlandtools.cn/db/ (NPC positions, scrip / token exchange
listings, and how each Disciple of the Hand / Land gear piece is obtained), fetched with
`tools/garland-data/fetch_garland.py` (throttled, cached). The plugin never contacts the
site at runtime; the running client's Excel sheets stay authoritative for prices, stats
and which items exist, and the snapshot only fills what those rows cannot express. The
underlying data is FINAL FANTASY XIV game data, (c) SQUARE ENIX CO., LTD.

- Project: https://github.com/ufx/GarlandTools (CN deployment: garlandtools.cn)
- License: MIT

MIT License

Copyright (c) 2018 Chris Faulhaber

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Additional references

AtmoOmen/GatherBuddyReborn (`5038325beb301bcceb9b1ffbe40b9c973b23ddca`,
Apache-2.0) and GarlandTools-CN
(`95e7ce7e5b0ced16423524679cd67167bfffaaf6`, MIT) were reviewed for public
data semantics and interoperability patterns. Ruri interoperates with the
separately installed CN GatherBuddyReborn through its IPC v2 and version-guarded
CraftingGatherBridge reflection surface when the user selects it as the gathering
provider. Apart from the data files listed above, no GatherBuddyReborn or
GarlandTools-CN code or runtime files are included in the Ruri plugin archive.

Ruri's built-in fisher (`Ruri.Fishing.dll`) is Ruri's own code. AutoHook
(InitialDet/Puni.sh, `79279f1`, BSD-3-Clause) and AtmoOmen/GatherBuddyReborn
(`e3c1e4c2`, Apache-2.0) were read as behaviour references only (which bites to
hook, mooch chains, Fisher's Intuition switching, GP action order); no code or
data files from either project are included. Action, status, item and log-message
ids were checked against the CN client's own sheets.

Ruri's cosmic exploration module (`Ruri.Cosmic.dll`) is Ruri's own code, written from a
clean-room behaviour spec. Its embedded game-fact data under `src/Ruri.Cosmic/Data/ice`
(gathering route node coordinates and stand sectors, fishing spot positions and headings, red
alert spots with NPC menu indices, and Bronze base class scores) was exported from
QiongHHHZZZ/Ices-Cosmic-Exploration (`89dc1c1b`, GPL-3.0 / AGPL-3.0-or-later) with the owner's
approval; only coordinates, ids and numbers were taken, no code. Ids were cross-checked against
the CN client's own sheets.

Ruri's quest engine (`Ruri.Quests.dll`) is Ruri's own code; no Questionable code is included. Its
embedded data under `src/Ruri.Quests/Data` (quest and object ids, positions, territories, item ids,
quest variables and text keys in `quest-steps.json.gz` and `gathering-points.json.gz`, and quest
names and accept conditions derived from them) was exported from PunishXIV/Questionable
(`272865e1`, AGPL-3.0); see `src/Ruri.Quests/Data/NOTICE.md`.
